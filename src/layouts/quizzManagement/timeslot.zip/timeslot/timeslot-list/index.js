import { useState, useEffect } from "react";
import { Link } from "react-router-dom";

// @mui material components
import Card from "@mui/material/Card";
import Stack from "@mui/material/Stack";

// Soft UI Dashboard PRO React components
import SuiBox from "components/SuiBox";
import SuiTypography from "components/SuiTypography";
import SuiButton from "components/SuiButton";

// Soft UI Dashboard PRO React example components
import DashboardLayout from "examples/LayoutContainers/DashboardLayout";
import DashboardNavbar from "examples/Navbars/DashboardNavbar";
import Footer from "examples/Footer";
import DataTable from "examples/Tables/DataTable";
// Data
import Table from "examples/Tables/Table";
import dataTableData from "layouts/quizzManagement/timeslot/timeslot-list/data/dataTableData";

function ProductsList() {
  const [isLoading, setIsLoading] = useState(false);
  const [columns] = useState([
    { name: "id", align: "center" },
    { name: "start_time", align: "center" },
    { name: "end_time", align: "center" },
  ]);
  const [data, setDate] = useState([]);
  useEffect(async () => {
    setIsLoading(true);
    let result = await fetch("http://localhost:8000/api/admin/timeslot/");
    result = await result.json();
    setDate(result);
    setIsLoading(false);
  }, []);
  return (
    <DashboardLayout>
      <DashboardNavbar />
      <SuiBox my={3}>
        <Card>
          <SuiBox display="flex" justifyContent="space-between" alignItems="flex-start" p={3}>
            <SuiBox lineHeight={1}>
              <SuiTypography variant="h5" fontWeight="medium">
                Time slot
              </SuiTypography>
            </SuiBox>
            <Stack spacing={1} direction="row">
              <Link to="/QuizzManagement/Slot/addtimeslot" className="decoration-none">
                <SuiButton variant="gradient" buttonColor="info" size="small">
                  + Add new time slot
                </SuiButton>
                {!isLoading ? (
                  <button type="submit" className="btnPayment mt-5">
                    LOGIN NOW
                  </button>
                ) : (
                  "Processing..."
                )}
              </Link>
            </Stack>
          </SuiBox>
          <Table columns={columns} rows={data.data} />
          <DataTable
            table={dataTableData}
            entriesPerPage={{
              defaultValue: 7,
              entries: [5, 7, 10, 15, 20, 25],
            }}
            canSearch
          />
        </Card>
      </SuiBox>
      <Footer />
    </DashboardLayout>
  );
}

export default ProductsList;
